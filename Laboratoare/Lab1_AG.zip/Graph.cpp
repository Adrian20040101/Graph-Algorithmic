#include "Graph.h"
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

Graph::Graph(){

    ifstream f;
    f.open("data2.in");
    f >> n;
    f >> m;
    int x, y;
    for (int i = 0; i < m; i++) {
        f>>x>>y;
        addEdge(x, y);
    }
}

void Graph::addEdge(int x, int y){
    matrix[x][y] = 1;
    matrix[y][x] = 1;
}

bool Graph::isEdge(int x, int y){
    return matrix[x][y] == 1;
}

void Graph::printGraph(){
    for (int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            cout<<matrix[i][j]<<" ";
        }
        cout<<endl;
    }
}

void Graph::maxGrad(){
    int ct = 0, ctmax = 0;
    for (int i = 0; i<n; i++){
        for (int j = 0; j<n; j++)
            if (matrix[i][j] == 1)
                ct++;
        if (ct > ctmax)
            ctmax = ct;
        ct = 0;
    }
    cout<<"Max grad of the graph is "<<ctmax;
}

void Graph::minGrad(){
    int ct = 0, ctmin = 10;
    for (int i = 0; i<n; i++){
        for (int j = 0; j<n; j++)
            if (matrix[i][j] == 1)
                ct++;
        if (ct < ctmin)
            ctmin = ct;
        ct = 0;
    }
    cout<<"Min grad of the graph is "<<ctmin;
}

void Graph::adjacencyList(){
    for (int i = 0; i<n; i++){
        cout<<i+1<<": ";
        for (int j=0 ; j<n ;j++){
            if (matrix[i][j] == 1)
                cout<<j+1<<" ";
            }
        cout<<endl;
    }
}

void Graph::komplement(){
    int kompl_matrix[100][100];
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            if (matrix[i][j] == 1){
                kompl_matrix[i][j] = 0;
            }
            else{
                kompl_matrix[i][j] = 1;
            }
        }
    }
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++) {
            cout<<kompl_matrix[i][j]<<" ";
        }
        cout<<endl;
        }
}

void Graph::show_kanten(){
    cout<<"Initial graph:"<<endl;
    for (int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            cout<<matrix[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<"Komplement graph:"<<endl;
    int kompl_matrix[100][100];
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            if (matrix[i][j] == 1){
                kompl_matrix[i][j] = 0;
            }
            else{
                kompl_matrix[i][j] = 1;
            }
        }
    }
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++) {
            cout<<kompl_matrix[i][j]<<" ";
        }
        cout<<endl;
    }
}
