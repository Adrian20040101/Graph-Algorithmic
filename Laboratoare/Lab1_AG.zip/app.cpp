#include "GraphAdjacentList.h"

#include<iostream>
#include<fstream>

using namespace std;

int main(){

    GraphAdiazenzListe g;
    cout<<g.isEdge(0,1)<<endl;
    g.printGraph();
    //g.maxGrad();
    cout<<endl;
    //g.minGrad();
    cout<<endl;
    //g.adjacencyList();
    //g.show_kanten();

}