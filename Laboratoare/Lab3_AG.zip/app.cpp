#include "GraphAdiazenzListe.h"
#include <iostream>

using namespace std;

int main() {

    //Graph g;
    //cout << g.isEdge(0, 1) << endl;
    //g.printGraph();

    //cout << "Max Grad = " << g.maxGradMat() << endl;
    //cout << "Min Grad = " << g.minGradMat() << endl;

    //g.addEdge(0, 3);
    //cout << "Edge added [0, 3]." << endl;

    //cout << "Max Grad = " << g.maxGradMat() << endl;
    //cout << "Min Grad = " << g.minGradMat() << endl;

    //cout << endl << endl;

    //AdjList g1("10k.txt");
    //AdjList g2("100k.txt");
    //AdjList g3("1m.txt");
    //gl.printGraph();

    //cout << gl.isEdge(0, 1) << endl;

    //cout<<"BFS: ";
    //gl.BFS(0);
    //cout<<g1.weg(0,7738)<<endl;
    //cout<<g1.weg(793,6174)<<endl;
    //cout<<g2.weg(81768,55850)<<endl;
    //cout<<g2.weg(19126,53548)<<endl;
    //cout<<g3.weg(696751,505396)<<endl;
    //cout<<g3.weg(0,895812)<<endl;

    //cout << "Max Grad = " << gl.maxGradListe() << endl;
    //cout << "Min Grad = " << gl.minGradListe() << endl;

    AdjList g1("data.in");
    std::cout << "Number of conex components in this graph is: " << g1.AnzahlKomponenten() << endl;
    std::cout<<g1.isTree();
}