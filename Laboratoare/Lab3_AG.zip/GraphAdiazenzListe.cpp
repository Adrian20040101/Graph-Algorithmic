#include "GraphAdiazenzListe.h"
#include <iostream>
#include <fstream>
#include <queue>
#include <stack>

using namespace std;

AdjList::AdjList(const std::string& filename) {
    ifstream f;
    f.open(filename);
    f >> nodes;
    f >> links;
    adjVector = new std::vector<int>[nodes];
    int x, y;
    for (int i = 0; i < links; i++) {
        f >> x >> y;
        addEdge(x, y);
    }
}

void AdjList::addEdge(int x, int y) {
    adjVector[x].push_back(y);
    adjVector[y].push_back(x);
}

bool AdjList::isEdge(int x, int y) {
    for (int i = 0; i < nodes; i++)
        if (adjVector[x][i] == y)
            return true;

    return false;
}


void AdjList::BFS(int start) {
    std::vector<bool> visited(nodes, false);
    std::queue<int> q;

    q.push(start);
    visited[start] = true;

    while (!q.empty()) {
        int current = q.front();
        q.pop();

        cout << current << " ";

        for (int adjNode: adjVector[current]) {
            if (!visited[adjNode]) {
                visited[adjNode] = true;
                q.push(adjNode);
            }
        }
    }
}

void AdjList::DFS(int startNode) {
    vector<bool> visited(nodes, false);
    stack<int> nodeStack;
    int currentNode = startNode;

    for (int iteration = 0; iteration < nodes; iteration++) {
        cout << currentNode << ' ';
        visited[currentNode] = true;

        // adds all unvisited neighbours in the stack, pushing the larger values first
        for (int node2 = nodes; node2 >= 0; node2--)
            if (isEdge(currentNode, node2) && !visited[node2])
                nodeStack.push(node2);

        currentNode = nodeStack.top();
        nodeStack.pop();
    }
}

int AdjList::weg(int start, int target) {
    std::vector<bool> visited(nodes, false);
    std::vector<int> distances(nodes, -1);
    std::queue<int> q;

    q.push(start);
    visited[start] = true;
    distances[start] = 0;

    while (!q.empty()) {
        int current = q.front();
        q.pop();

        if (current == target)
            return distances[target];

        for (int node: adjVector[current]) {
            if (!visited[node]) {
                visited[node] = true;
                q.push(node);
                distances[node] = distances[current] + 1;
            }
        }
    }
    cout << "Kein Weg von "<< start << " bis zu "<< target;
    return -1;
}

int AdjList::AnzahlKomponenten() {
    if (nodes == 0) {
        return 0;
    }

    vector<bool> visited(nodes, false); // initializes a vector to keep track of visited nodes
    int numComponents = 0;

    for (int i = 0; i < nodes; i++) {
        if (!visited[i]) { // if the current node is unvisited
            numComponents++; // increment the number of components
            std::stack<int> stack;
            stack.push(i);

            while (!stack.empty()) {   //as long as there are nodes to visit
                int node = stack.top();
                stack.pop();
                visited[node] = true;

                // Add all unvisited neighbors to the stack
                for (auto neighbor : adjVector[node]) {
                    if (!visited[neighbor]) {
                        stack.push(neighbor);
                    }
                }
            }
        }
    }
    return numComponents;
}

bool AdjList::isTree() {
    int numComponents = AnzahlKomponenten();
    std::vector<int> component;

    // determining the sizes and nodes of each conex component
    for (int i = 0; i < numComponents; i++) {  //looping through the nodes and checking if they belong to the current component
        int componentSize = 0;
        int numLinks = 0;
        for (int j = 0; j < nodes; j++) {
            if (component[j] == i) {
                componentSize++;
                numLinks++;
            }
        }
        if (numLinks != componentSize - 1) {
            return false;
        }
    }
    return true;
}

AdjList::~AdjList() {
    delete[] adjVector;
}