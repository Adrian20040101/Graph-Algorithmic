#include <vector>
#include <string>

class AdjList {
private:
    int nodes{};
    int links{};
    std::vector<int> *adjVector;

public:
    AdjList(const std::string& filename);

    void addEdge(int x, int y);

    bool isEdge(int x, int y);

    void BFS(int startNode);

    void DFS(int startNode);

    int weg(int start_node, int endNode);

    int AnzahlKomponenten();

    bool isTree();

    ~AdjList();
};