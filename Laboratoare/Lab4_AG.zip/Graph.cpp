#include "Graph.h"
#include <stack>
#include <iostream>

Graph::Graph(const string &fileName) {
    std::ifstream inputFile(fileName);
    Node* node = new Node{};

    while (inputFile >> node->city1 >> node->city2 >> node->weight){
        edgeCount++;

        // Insert unique cities in the set
        allCities.insert(node->city1);
        allCities.insert(node->city2);

        auto newNode = new Node{node->city1, node->city2, node->weight, nullptr};
        if (!head) {
            head = newNode;
        } else {
            // Iterate through the whole list and set the next pointer of the last city to the city that has just been added
            auto current = head;
            while (current->next) {
                current = current->next;
            }
            current->next = newNode;
        }
    }
    // Determine the number of cities in the set
    cityCount = allCities.size();
}


void Graph::printGraph() const {
    Node* current = head;
    while (current) {
        std::cout << current->city1 << current->city2 << current->weight << std::endl;
        current = current->next;
    }
}

void Graph::shortestPath(const string& city1, const string& city2) {
// Create a set to store visited nodes
    std::set<string> visitedCities;

// Create a map to store the shortest distance from the starting city
    std::map<string, int> shortestPath;

// Create a map to store the previous city in the shortest path
    std::map<string, string> previousCity;

// Initialize the head of the list
    Node* currentNode = head;

// Initialize a variable that keeps track of the total cost count
    int totalCost;

// Setting initial weights for each path between city and initializing previous city that will help in backtracking
    while (currentNode != nullptr) {
        shortestPath[currentNode->city1] = INT16_MAX;
        shortestPath[currentNode->city2] = INT16_MAX;
        previousCity[currentNode->city1] = "";
        previousCity[currentNode->city2] = "";
        currentNode = currentNode->next;
    }

// Set the distance of the starting city to 0
    shortestPath[city1] = 0;

// Loop until all cities have been visited
    while (visitedCities.size() < cityCount) {
        // Find the city with the minimum distance that hasn't been visited
        string currentCity;
        int minDistance = INT16_MAX;
        for (const auto& distance : shortestPath) {
            // Verify if the city has not been visited and if its distance is less than the current minimum distance
            if (visitedCities.count(distance.first) == 0 && distance.second < minDistance) {
                currentCity = distance.first;
                minDistance = distance.second;
            }
        }

        // Mark the current city as visited
        visitedCities.insert(currentCity);

        // Update the distances of the neighboring cities
        currentNode = head;
        while (currentNode) {
            // If city2 is a neighbor of currentCity
            if (currentNode->city1 == currentCity) {
                int newDistance = shortestPath[currentCity] + currentNode->weight;
                // Update the shortest distance
                if (newDistance < shortestPath[currentNode->city2]) {
                    shortestPath[currentNode->city2] = newDistance;
                    // Stores the previous city on the shortest path to the neighboring city
                    previousCity[currentNode->city2] = currentCity;
                }
            }
            // If city1 is a neighbor of currentCity
            else if (currentNode->city2 == currentCity) {
                int newDistance = shortestPath[currentCity] + currentNode->weight;
                if (newDistance < shortestPath[currentNode->city1]) {
                    shortestPath[currentNode->city1] = newDistance;
                    previousCity[currentNode->city1] = currentCity;
                }
            }
            currentNode = currentNode->next;
        }
    }

// Check if a path exists between the two cities
    if (previousCity[city2].empty()) {
        std::cout << "No path exists between " << city1 << " and " << city2 << std::endl;
        return;
    }

// Backtrack from the destination city to the starting city to find the shortest path
    std::stack<string> path;
    string currentCity = city2;
    while (!currentCity.empty()) {
        path.push(currentCity);
        currentCity = previousCity[currentCity];
    }

// Assigning the total cost of the path to the variable created in this scope
    totalCost = shortestPath[city2];

// Print the shortest path
    std::cout << "Shortest path from " << city1 << " to " << city2 << ": ";
    while (!path.empty()) {
        std::cout << path.top() << " ";
        path.pop();
    }
    std::cout << std::endl;
    std::cout << "Total cost of the path is " << totalCost;
    std::cout << std::endl;
}