#pragma once
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <set>
#include <map>

using std::vector, std::string;

struct Node{
    string city1;
    string city2;
    int weight;
    Node* next;
};

class Graph{
private:
    Node *head = nullptr;
    int cityCount = 0;
    int edgeCount = 0;
    std::set<string> allCities{};  // Initialize a set that will contain the cities. We use set since we don't want to cover duplicate cities


public:
    //Constructor with 1 parameter
    explicit Graph(const string &fileName);

    //Copy constructor
    Graph(const Graph &other) = default;

    //Destructor
    ~Graph() = default;

    //Print the Graph
    void printGraph() const;

    void shortestPath(const string& city1, const string& city2);
};