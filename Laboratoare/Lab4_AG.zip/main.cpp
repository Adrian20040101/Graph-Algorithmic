#include <iostream>

#include "Graph.h"

int main() {
    Graph graph("Graph.txt");
    //graph.printGraph();

    graph.shortestPath("Savannah", "Sacramento");

    return 0;
}
